<?php
$connect = new mysqli("localhost","x_u_10542_login","login","x_u_10542_login");
mysqli_set_charset($connect, "utf8mb4");
?>